import express from "express";
import bodyParser from "body-parser";
import pg from "pg";

const app = express();
const port = 3000;

const db= new pg.Client({
  user:"postgres",
  host:"localhost",
  database:"world",
  password:"",
  port:5432
});
db.connect();


app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));



async function todoitems(){
  const result=await db.query("SELECT * from todolist");
  let items = [];
  result.rows.forEach((temp)=>{
    items.push(temp);
  });
  return items;
}

app.get("/", async(req, res) => { 
  const titems=await todoitems();
  console.log(titems);
  res.render("index.ejs", {
    listTitle: "Today",
    listItems: titems
  });
});

app.post("/add", async(req, res) => {
  const item = req.body.newItem;
  console.log(item);
  await db.query("INSERT INTO todolist (title) VALUES ($1)",[item]);
  res.redirect("/");
});

app.post("/edit", async(req, res) => {
  const itemid=req.body.updatedItemId;
  const itemtitle=req.body.updatedItemTitle;
  await db.query("UPDATE todolist SET title=$1 where id=$2",[itemtitle,itemid]);
  console.log(itemid);
  console.log(itemtitle);
  res.redirect("/");
});

app.post("/delete", async(req, res) => {
  const ditemid=req.body.deleteItemId;
  await db.query("DELETE from todolist WHERE id=$1",[ditemid]);
  res.redirect("/");

});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
